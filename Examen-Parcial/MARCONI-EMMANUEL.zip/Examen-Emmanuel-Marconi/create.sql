create table IF NOT EXISTS odontologos(id int auto_increment primary key,matricula int,nombre varchar (255),apellido varchar (255));
